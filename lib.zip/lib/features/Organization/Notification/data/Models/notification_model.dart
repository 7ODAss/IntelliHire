import 'package:intelli_hire/core/utils/shared/date_formatter.dart';
import '../../domain/Entities/notification_entity.dart';

class NotificationModel extends NotificationEntity {
  NotificationModel({
    required super.id,
    required super.title,
    required super.description,
    required super.time,
    super.isRead = false,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    String rawTime =
        json['time']?.toString() ?? json['createdAt']?.toString() ?? '';

    if (rawTime.isEmpty) {
      rawTime = DateTime.now().toIso8601String();
    }

    String formattedTime = 'Now';
    if (rawTime.contains('T')) {
      formattedTime = rawTime.toTimeAgo();
    } else {
      formattedTime = rawTime;
    }

    return NotificationModel(
      id:
          json['id']?.toString() ??
          json['Id']?.toString() ??
          DateTime.now().millisecondsSinceEpoch.toString(),
      title: json['title'] ?? json['Title'] ?? '',
      description: json['description'] ?? json['body'] ?? '',
      time: formattedTime,
      isRead: json['isRead'] ?? json['IsRead'] ?? false,
    );
  }
}

import 'package:intelli_hire/features/Organization/Home/domain/entities/home_entity.dart';


abstract class HomeState {}
class HomeInitial extends HomeState {}
class HomeLoading extends HomeState {}
class HomeLoaded extends HomeState {
  final HomeEntity dashboardData;
  HomeLoaded(this.dashboardData);
}
class HomeError extends HomeState {
  final String message;
  HomeError(this.message);
}
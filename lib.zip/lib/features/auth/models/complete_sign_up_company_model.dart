
class CompleteSignUpCompanyModel{

}
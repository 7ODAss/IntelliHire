import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intelli_hire/features/auth/controller/sign_up_cubit/sign_up_cubit.dart';
import 'package:intelli_hire/features/auth/controller/external%20login/external_login_cubit.dart';
import 'package:intelli_hire/features/auth/controller/external%20login/external_login_state.dart';
import 'package:intelli_hire/features/auth/presentation/signup/company/process/sign_up_information_company.dart';
import 'package:intelli_hire/features/auth/presentation/signup/company/widget/check_email_screen.dart';
import 'package:intelli_hire/features/auth/presentation/signup/company/widget/navigator_to_account.dart';
import 'package:intelli_hire/features/auth/presentation/signup/company/widget/pop_action.dart';
import 'package:intelli_hire/features/auth/presentation/signup/Candidate%20Signup/views/widget/shared/social_buttons.dart';
import '../../../../../core/enums/request.dart';
import '../../../../../core/enums/snack_bar_type.dart';
import '../../../../../core/utils/app_text_style.dart';
import '../../../../../core/utils/shared/auth_layout.dart';
import '../../../../../core/utils/shared/context_extension.dart';
import '../../login/login_screen.dart';
import '../../login/widget/button_action.dart';
import '../../login/widget/field_item.dart';
import '../../../../Organization/bottom _navigation/presentation/custom_bottom_nav_bar_wrapper.dart';
import '../../../../candidate/bottom _navigation/presentation/custom_bottom_nav_bar_wrapper_candidate.dart';

class SignUpCompany extends StatefulWidget {
  const SignUpCompany({super.key});

  @override
  State<SignUpCompany> createState() => _SignUpCompanyState();
}

class _SignUpCompanyState extends State<SignUpCompany> {
  late TextEditingController workEmailController;
  late TextEditingController workPasswordController;
  late TextEditingController workConfirmPasswordController;
  late GlobalKey<FormState> workFormKey;

  @override
  void initState() {
    super.initState();
    workEmailController = TextEditingController();
    workPasswordController = TextEditingController();
    workConfirmPasswordController = TextEditingController();
    workFormKey = GlobalKey<FormState>();
  }

  @override
  void dispose() {
    workEmailController.dispose();
    workPasswordController.dispose();
    workConfirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => SignUpCubit(),
      // 🔴 نغلف الـ Scaffold بـ BlocListener الخاص بالـ External Login
      child: BlocListener<ExternalLoginCubit, ExternalLoginState>(
        listener: (context, state) {
          if (state is ExternalLoginSuccess) {
            // منطق التوجيه حسب الـ userType والـ isProfileComplete
            if (!state.isProfileComplete) {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (_) => const SignUpInformationCompany(),
                ),
                (route) => false,
              );
            } else {
              if (state.userType == 'Company' || state.userType == 'company') {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const CustomBottomNavBarWrapper(),
                  ),
                  (route) => false,
                );
              } else {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const CustomBottomNavBarWrapperCandidate(),
                  ),
                  (route) => false,
                );
              }
            }
          } else if (state is ExternalLoginFailure) {
            context.showSnackBar(state.error, type: SnackBarType.error);
          }
        },
        child: BlocConsumer<SignUpCubit, SignUpState>(
          listener: (context, state) {
            if (state.signUpState == RequestState.success) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => const CheckEmailScreen(),
                ),
              );
            } else if (state.signUpState == RequestState.error) {
              context.showSnackBar(
                state.signUpMessage,
                type: SnackBarType.error,
              );
            }
          },
          builder: (context, state) {
            final cubit = context.read<SignUpCubit>();
            return Form(
              key: workFormKey,
              child: Scaffold(
                body: AuthLayout(
                  bodyColor: const Color(0xFFF8FAFC),
                  headerContent: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: PopAction(),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'Welcome to IntelliHire',
                        style: AppTextStyle.signUpTitleStyle,
                      ),
                      Text(
                        'Step into the future of hiring',
                        style: AppTextStyle.loginSubTitleStyle,
                      ),
                    ],
                  ),
                  bodyContent: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 48,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          FieldItem(
                            controller: workEmailController,
                            title: 'Work Email',
                            message: 'Enter Your Work Email',
                            type: TextInputType.emailAddress,
                          ),
                          const SizedBox(height: 16),
                          // ... (أكواد الـ FieldItem للباسورد كما هي عندك)
                          // تأكد من تمرير 'Company' في الـ SocialButtons
                          const SocialButtons(type: 'Company'),
                          const SizedBox(height: 24),
                          ButtonAction(
                            title: 'Create Account',
                            isLoading:
                                state.signUpState == RequestState.loading,
                            onPressed: () {
                              if (workFormKey.currentState!.validate()) {
                                cubit.signUpCompany(
                                  email: workEmailController.text,
                                  password: workPasswordController.text,
                                  confirmPassword:
                                      workConfirmPasswordController.text,
                                );
                              }
                            },
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 32.0,
                              horizontal: 80,
                            ),
                            child: NavigatorToAccount(
                              text: 'Already have account?',
                              actionText: ' Log in',
                              onTap: () => Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const LoginScreen(),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

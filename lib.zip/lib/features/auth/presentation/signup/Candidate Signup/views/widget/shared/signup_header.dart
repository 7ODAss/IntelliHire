import 'package:flutter/material.dart';
import '../../../../../../../../core/utils/app_text_style.dart';
import '../../../../company/widget/pop_action.dart';

class SignupHeader extends StatelessWidget {
  const SignupHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const Image(
          image: AssetImage("assets/image/auth_background.png"),
          width: double.infinity,
          fit: BoxFit.cover,
        ),
        const SizedBox(height: 16),
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 24, top: 55),
              child: PopAction(),
            ),
            Text("Welcome to IntelliHire", style: AppTextStyle.textstyle20),
            const SizedBox(height: 8),
            Text(
              "Step into the future of hiring",
              style: AppTextStyle.textstyle12,
            ),
          ],
        ),
      ],
    );
  }
}

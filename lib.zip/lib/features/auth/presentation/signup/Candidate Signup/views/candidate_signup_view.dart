import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intelli_hire/core/service/api_service.dart';
import 'package:intelli_hire/core/enums/snack_bar_type.dart';
import 'package:intelli_hire/core/utils/shared/context_extension.dart';
import 'package:intelli_hire/features/auth/controller/external%20login/external_login_cubit.dart';
import 'package:intelli_hire/features/auth/controller/external%20login/external_login_state.dart';
import 'package:intelli_hire/features/auth/controller/profile%20setup%20cubit/profile_setup_cubit.dart';
import 'package:intelli_hire/features/auth/presentation/signup/Candidate%20Signup/views/account_setup_view.dart';
import 'package:intelli_hire/features/auth/presentation/signup/Candidate%20Signup/views/widget/shared/custom_text_field.dart';
import 'package:intelli_hire/features/auth/presentation/signup/Candidate%20Signup/views/widget/shared/footer.dart';
import 'package:intelli_hire/features/auth/presentation/signup/Candidate%20Signup/views/widget/shared/or_dvider.dart';
import 'package:intelli_hire/features/auth/presentation/signup/Candidate%20Signup/views/widget/shared/signup_header.dart';
import 'package:intelli_hire/features/auth/presentation/signup/Candidate%20Signup/views/widget/shared/social_buttons.dart';
import '../../../login/login_screen.dart';
import 'package:intelli_hire/features/candidate/bottom%20_navigation/presentation/custom_bottom_nav_bar_wrapper_candidate.dart';
import 'package:intelli_hire/features/Organization/bottom%20_navigation/presentation/custom_bottom_nav_bar_wrapper.dart';

class CandidateSignUpView extends StatefulWidget {
  const CandidateSignUpView({super.key});

  @override
  State<CandidateSignUpView> createState() => _CandidateSignUpState();
}

class _CandidateSignUpState extends State<CandidateSignUpView> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 🔴 BlocListener للاستماع لنتائج تسجيل الدخول الخارجي
      body: BlocListener<ExternalLoginCubit, ExternalLoginState>(
        listener: (context, state) {
          if (state is ExternalLoginSuccess) {
            // التحقق من اكتمال البروفايل
            if (!state.isProfileComplete) {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (_) => BlocProvider(
                    create: (context) =>
                        ProfileSetupCubit(ApiService(), userToken: state.token),
                    child: const AccountSetupView(),
                  ),
                ),
                (route) => false,
              );
            } else {
              // توجيه حسب نوع الحساب الحقيقي
              if (state.userType == 'Company') {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const CustomBottomNavBarWrapper(),
                  ),
                  (route) => false,
                );
              } else {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const CustomBottomNavBarWrapperCandidate(),
                  ),
                  (route) => false,
                );
              }
            }
          } else if (state is ExternalLoginFailure) {
            context.showSnackBar(state.error, type: SnackBarType.error);
          }
        },
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SignupHeader(),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    children: [
                      // ... (حقول الإدخال كما هي)
                      CustomTextField(
                        hint: "Full Name",
                        controller: _nameController,
                      ),
                      const SizedBox(height: 8),
                      CustomTextField(
                        hint: "Email",
                        controller: _emailController,
                      ),
                      const SizedBox(height: 8),
                      CustomTextField(
                        hint: "Password",
                        isPassword: true,
                        controller: _passwordController,
                      ),
                      const SizedBox(height: 8),
                      CustomTextField(
                        hint: "Confirm Password",
                        isPassword: true,
                        controller: _confirmPasswordController,
                      ),

                      const SizedBox(height: 24),

                      // ... (الـ BlocConsumer الخاص بالتسجيل العادي كما هو)
                      const SizedBox(height: 24),
                      const OrDvider(),
                      const SizedBox(height: 24),
                      // 🔴 تمرير 'Candidate' هنا
                      const SocialButtons(type: 'Candidate'),
                      const SizedBox(height: 24),
                      Footer(
                        onPressed: () => Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const LoginScreen(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'dart:ui';

import 'package:flutter/material.dart';

class AppColor {
  // onboarding_svg colors
  static const Color titleColor = Color(0xFF0F172A);
  static const Color subTitleColor = Color(0xFF475569);
  static const Color logicColor = Color(0xFF134CC7);
  static const Color notActiveIndicatorColor = Color(0xFFAFAFAF);
  static const Color backgroundColor = Color(0xFFF8FAFC);

  // landing_svg colors
  static const Color landingTitleColor = Color(0xFF0F172A);
  static const Color landingAccountColor = Color(0xFF9CA3AF);
  static const Color landingCardColor = Color(0xFFF8FAFC);

  // login colors
  static const Color loginTitleColor = Color(0xFFF2F2F2);
  static const Color loginSubTitleColor = Color(0xFF9CA3AF);
  static const Color loginButtonColor = Color(0xFFFFFFFF);
  static const Color loginButtonBackgroundColor = Color(0xFF134CC7);
  static const Color mircoSoftButtonBorderColor = Color(0xFFFFFFFF);

  //signup company fields colors
  static const Color signUpTitleColor = Color(0xFFF2F2F2);
  static const Color signUpFieldColor = Color(0xFF0F172A);
  static const Color signUpConditionColor1 = Color(0xFF9CA3AF);
  static const Color signUpConditionColor2 = Color(0xFF134CC7);
  static const Color signUpTitleInformationCompanyColor = Color(0xFFFFFFFF);
  static const Color hintColor = Color(0xFF898989);
  static const Color searchTitleColor = Color(0xFF0F172A);
  static const Color searchItemColor = Color(0xFF134CC7);
  static const Color searchCardItemColor = Color(0xFFEDEFFE);

  //omar
  static const Color primary = Color(0xFF134CC7);
  static const Color secondary = Color(0xFF0B1B3F);
  static const Color darkBlue = Color(0xff0F172A);
  static const Color grey = Color(0xff9CA3AF);
  static const Color white = Color(0xffF2F2F2);

  //////////////////////

  //postScreen
  static const Color titlePostScreenColor = Color(0xFF475569);
  static const Color iconProfileBorderColor = Color(0xFF134CC7);
  static const Color iconProfile2BorderColor = Colors.red;
  static const Color iconProfileColor = Color(0xFFF1F0F1);
  static const Color accountNameProfileColor = Color(0xFF0F172A);
  static const Color accountSubNameProfileColor = Color(0xFF475569);
  static const Color accountTitleFieldColor = Color(0xFF0F172A);
  //company details edit
  static const Color addLocationButtonBackGroundColor = Color(0xFFEDEFFE);
  static const Color addLocationButtonTextColor = Color(0xFF426FF9);
}

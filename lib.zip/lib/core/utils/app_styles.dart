
abstract class AppStyles {

}
